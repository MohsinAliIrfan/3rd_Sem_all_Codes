#include"Numbera.h"

class FunWithNumbers
{
	const int size;
	Numbers* values;
public:
	FunWithNumbers(const int n,const Numbers& p);
	FunWithNumbers(const FunWithNumbers& mc);
	void print();
};
ostream& operator <<(ostream& out, const FunWithNumbers& obj);