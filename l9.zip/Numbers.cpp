#include"Numbera.h"

float* copy(const float* p, const int& s)
{
	float* a = new float[s];
	for (int i = 0; i < s; i++)
		a[i] = p[i];
	return a;
}

Numbers::Numbers(const int n, const float* p)
{
	no = n;
	elements = copy(p, n);
}
Numbers::Numbers(const Numbers& f)
{
	no = f.no;
	elements = copy(f.elements, no);
}
void Numbers::print()const
{
	cout << "Number : no = " << no << "elements {";
	for (int i = 0; i < no; i++){
		cout << elements[i];
		if (i < no - 1)
			cout << ",";
	}
	cout << "} </Numbers ";
}

Numbers Numbers::operator+(Numbers& obj) 
{
	Numbers temp;
	temp.elements = new float[5];
	temp.no = this->no + obj.no;
	
	for (int i = 0; i < 5; i++) 
		temp.elements[i] = this->elements[i] + obj.elements[i];

	return temp;
}

Numbers Numbers::operator++(int)
{
	Numbers obj;
	obj.no = this->no + 1;
	return obj;
}
Numbers Numbers::operator--(int) 
{
	Numbers obj;
	obj.no = this->no - 1;
	return obj;
}
void Numbers::operator=(const Numbers &obj) 
{
	this->no = obj.no;
	this->elements = obj.elements;
}
bool Numbers::operator==(const Numbers &obj)
{
	if (this->no == obj.no && this->elements == obj.elements)
		return true;
	return false;
}
float& Numbers:: operator[](int index) {
	return elements[index];
}