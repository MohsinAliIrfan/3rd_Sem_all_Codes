#include<iostream>
using namespace std;
#pragma once

float* copy(const float* p, const int& s);

class Numbers
{
	int no;
	float* elements;
public:
	Numbers(const int n = 0, const float* p = nullptr);
	Numbers(const Numbers& f);
	Numbers operator +(Numbers& obj);
	bool operator == (const Numbers& obj);
	void operator = (const Numbers& obj);
	Numbers operator++(int);
	Numbers operator --(int);
	float& operator[](int x);
	void print()const;

};