#include"FunWithNumbers.h"


FunWithNumbers::FunWithNumbers(const int n, const Numbers& p):size(n){
	values = copy(p, size);
}
FunWithNumbers::FunWithNumbers(const FunWithNumbers& obj) : size(obj.size){
	values = copy(obj.values, obj.size);

}
void FunWithNumbers::print()const
{
	cout << "FunWithNumbers: Size = " << size << "values = {";
	for (int i = 0; i < size; i++)
	{
		//values[i].print();
		cout << values[i];
		if (i < size - 1)
			cout << ", ";
	}
	cout << "} </FunWithNumbers\n" << endl;
}
ostream& operator <<(ostream& out, const FunWithNumbers& obj) {
	out << obj.print();
}