#include"Numbera.h"
#include"FunWith.h"
int main()
{
	const float fa[] = { 1.1, 2.2, 3.3, 4.4, 5.5 };
	Numbers N(5, fa);
	Numbers M(5, fa);
	Numbers* na = new Numbers[2];
	N + M;

	na[0] = N[0];
	na[1] = M[1];
	FunWithNumbers F(2, na);
	F.print();
	return 0;

}