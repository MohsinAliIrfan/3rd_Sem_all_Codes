#include<iostream>
using namespace std;
#pragma once

class MyString
{
	int size = 100, index = 0;
	char* arr;
public:
	MyString();
	MyString(int ind);
	MyString(const MyString& s1, int start, int end); // copy instructor for str2
    MyString(MyString& obj);
	void setsize(int size);
	void add(char ch);
	char* getarr() const;
	int length() const;
	void clear() const;
	MyString operator +(MyString &s2);
	MyString operator -(MyString& obj);
	char operator[](int ind);
	MyString &operator --(int);
	MyString& operator ++(int);
	MyString& operator --();
	MyString& operator ++();
	~MyString();
};
void print(const MyString& s);