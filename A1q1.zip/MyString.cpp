#include"MyString.h"

MyString::MyString(){
	arr = new char[100];
}

MyString::MyString(int ind) {
    this->arr = new char[ind];
}

void MyString::add(char ch)
{
    arr[index] = ch;
    arr[++index] = '\0';
}

MyString::MyString(const MyString& s1, int start, int end) // copy instructor
{
    index = 0;
    this->arr = new char[end];
    for (int i = 2; i <= end; i++)
        this->arr[index++] = s1.arr[i];
    this->arr[index] = '\0';
}

MyString::MyString(MyString& obj) 
{
    this->arr = new char[strlen(obj.arr) + 1];
    //cout << endl << this->arr;
    strcpy_s(this->arr, strlen(obj.arr) + 1, obj.arr);
}

char* MyString::getarr() const
{
    int size = strlen(arr);
    char* newarr = new char[size + 1];
    strcpy_s(newarr, size + 1, arr);
    return newarr;
}
void MyString::setsize(int size){
    this->index= size;
}
int MyString::length() const
{
    if (arr[0] >= 'a' || arr[0] <= 'z' || arr[0] >= 'A' || arr[0] <= 'Z' || arr[0] >= '0' || arr[0] <= '9' || arr[0] == '$' || arr[0] == '[')
        return strlen(arr);
    return 0;
}

void MyString::clear() const
{
    for (int i = 0; i < strlen(arr); i++)
        arr[i] = '\0';
}

MyString MyString::operator +(MyString &s2)
{
    int end = strlen(this->arr);
    for (int i = 0; i < strlen(s2.arr); i++)
        this->arr[end++] = s2.arr[i];
    return *this;

}

MyString  MyString::operator -(MyString& obj)
{
    int str = strlen(this->arr);
    int end = strlen(obj.arr);

    for (int i = 0; i <= end; i++)
        this->arr[str++] = obj.arr[i];
    this->arr[str] = '\0';
    size = strlen(this->arr);

    MyString temp1;
    strcpy_s(temp1.arr, size + 1, this->arr);
    //MyString temp;
    //temp = temp1;
    cout << "aya h";
 //   cout << "\n" << temp.arr;
    return temp1;
}
char MyString::operator [](int ind)
{
    if (ind >= 0 && ind< size)
        return arr[index];
    return arr[index];
}
MyString& MyString:: operator ++(int)
{
    size = strlen(arr);
    for (int i = 0; i < size; i++)
        arr[i] = arr[i] + 1;
    return *this;
}
MyString& MyString:: operator ++()
{
    size = strlen(arr);
    for (int i = 0; i < size; i++)
        arr[i] = arr[i] + 1;
    return *this;
}
MyString& MyString:: operator --()
{
    size = strlen(arr);
    for (int i = 0; i < size; i++)
        arr[i] = arr[i] + 1;
    return *this;
}

MyString& MyString:: operator --(int)
{
    MyString temp;
    size = strlen(arr);
    for (int i = 0; i < size; i++)
        arr[i] = arr[i] + 1;
    return *this;
}

MyString::~MyString(){
    if(arr)
      delete[]arr;
}

void print(const MyString& s)
{
    cout << " " << s.getarr();
}