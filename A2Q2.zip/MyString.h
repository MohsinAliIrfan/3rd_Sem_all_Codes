#include<iostream>
using namespace std;
#pragma once

class MyString
{
    char* arr;
    int csize;
    int index = 0;
public:
   // MyString(const MyString& obj);
    MyString();
    MyString(int size);
    MyString(const MyString& s1, int start, int end); // copy instructor for str2
    void indexx();
    void add(char ch);
    int length() const;
    char *getarr() const;
    void clear() const;
    MyString operator+(MyString s2);
    void print() const;
    MyString operator -(MyString& obj);
    MyString operator[](MyString obj);
    MyString &operator ++();
    MyString &operator --();
    MyString  operator--(int);
    MyString  operator++(int);
};

void print(MyString& s);

