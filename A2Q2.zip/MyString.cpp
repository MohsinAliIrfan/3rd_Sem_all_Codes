#include "MyString.h"

/*MyString::MyString(const MyString& obj)
{
    //  this->arr = new char[100];
    cout << endl << obj.arr;
    csize = strlen(obj.arr);
    strcpy_s(this->arr, csize + 1, obj.arr);
    cout << "helllo";
}*/

MyString::MyString()
{
    arr = new char[100];
}
MyString::MyString(int size)
{
    index = 0;
    arr = new char[size];
}

MyString::MyString(const MyString& s1, int start, int end) // copy instructor for str2
{
    index = 0;
    this->arr = new char[end];
    for (int i = 2; i <= end; i++)
        this->arr[index++] = s1.arr[i];
    this->arr[index] = '\0';
}

/*MyString(MyString &obj)
{
    cout << "\n\ Agia h";
    csize = strlen(obj.arr);
   // char* newarr = new char[1];
    strcpy_s(this->arr, csize + 1, obj.arr);
}*/
void MyString::indexx()
{
    index = 0;
}

void MyString::add(char ch)
{
    arr[index] = ch;
    arr[++index] = '\0';
    //   if (ch == '$')
           //cout << " " << ch;
}

int MyString::length() const
{
    return strlen(arr);
}

char* MyString::getarr() const
{
    int size = strlen(arr);
    char* newarr = new char[size + 1];
    strcpy_s(newarr, size + 1, arr);
    return newarr;
}

void MyString::clear() const
{
    for (int i = 0; i < strlen(arr); i++)
        arr[i] = '\0';
}

MyString MyString::operator+(MyString s2)
{
    int end = strlen(this->arr);
    for (int i = 0; i < strlen(s2.arr); i++)
        this->arr[end++] = s2.arr[i];
    return *this;

}

void  MyString::print() const
{
    cout << "\n String = " << this->getarr();
}

MyString  MyString::operator -(MyString& obj)
{
    int str = strlen(this->arr);
    int end = strlen(obj.arr);

    for (int i = 0; i <= end; i++)
        this->arr[str++] = obj.arr[i];
    this->arr[str] = '\0';
    csize = strlen(this->arr);

    MyString temp1;
    strcpy_s(temp1.arr, csize + 1, this->arr);
    //MyString temp;
    //temp = temp1;

 //   cout << "\n" << temp.arr;
    return temp1;

}

MyString  MyString::operator[](MyString obj)
{
    this->arr[1] += 1;
    return this[1];
}

MyString &MyString:: operator ++()
{
    csize = strlen(arr);
    for (int i = 0; i < csize; i++)
        arr[i] = arr[i] + 1;
    return *this;
}

MyString &MyString:: operator --()
{
    csize = strlen(arr);
    for (int i = 0; i < csize; i++)
        arr[i] = arr[i] + 1;
    return *this;
}

MyString MyString::operator++(int)
{
    MyString temp;
    temp = *this;
    for (int i = 0; i < csize; i++)
    {
        arr[i] = arr[i] + 1;
    }
    return temp;
}


MyString MyString::operator--(int)
{
    MyString temp;
    temp = *this;
    for (int i = 0; i < csize; i++)
    {
        arr[i] = arr[i] - 1;
    }
    return temp;
}

void print(MyString& s)
{
    cout << " " << s.getarr();
}
