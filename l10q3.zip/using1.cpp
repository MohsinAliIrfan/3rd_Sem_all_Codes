#include"base.h"
#include"Rectangle.h"

void BaseClass :: setwidth(int width) {
	this->width = width;
}
void  BaseClass ::setheight(int height) {
	this->height = height;
}
int  BaseClass::getwidth() {
	return width;
}
int  BaseClass::getheight() {
	return height;
}
void BaseClass::display() {
	cout << "\n Width = " << width;
	cout << "\n Hieght = " << height;
}

void RectangleArea::input(int height, int width) {
	this->height = height;
	this->width = width;
}
void RectangleArea::display() {
	cout << "\n Total Area is " << height * width;
}