#include "Rectangle.h"
#include "base.h"

int main()
{
	int width = 0, height = 0;
	cout << "\n Enter Width: "; cin >> width;
	cout << "\n Enter Height: "; cin >> height;

	BaseClass obj;
	cout << "\n Base Class ";
	obj.setwidth(width);
	obj.setheight(height);
	obj.display();

	cout << "\n\n Rectangle Area ";
	RectangleArea obj1;
	obj1.input(obj.getheight(), obj.getwidth());
	obj1.display();

	return 0;
}