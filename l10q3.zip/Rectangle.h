#include "base.h"

class RectangleArea : public BaseClass
{
	int width = 0;
	int height = 0;
public:
	//void area();
	void input(int height, int width);
	void display();
};