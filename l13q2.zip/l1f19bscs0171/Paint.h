#include "shape.h";

class Paint
{
	float amount;
	float area, cov_of_p;
public:
	void setcov(float covofpaint);
	void setarea(float area);
	void calculate();
	float getamount();
};