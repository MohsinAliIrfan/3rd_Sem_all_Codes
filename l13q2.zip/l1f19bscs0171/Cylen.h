#include "Shape.h"

class Cylen :public Shape
{
	float rad, height;
	float cal;
	const int Pi;
public:
	Cylen(float pi);
	void setrad(float rad);
	void setheight(float height);
	float getrad();
	float getheight();
	float getarea();
	void area();
};