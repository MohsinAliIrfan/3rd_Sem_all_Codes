#include "Shape.h"
#include "Sphere.h"
#include "Rec.h"
#include "Cylen.h"
#include "Paint.h"

//shape
Shape::Shape() {shapename = new char[30]{}; }
void Shape::area() {int areaval = 0; }
void Shape::setname(char* name) {this->shapename = name; }
char* Shape::tostring()
{
	char* temp = new char[strlen(shapename) + 1];
	strcpy_s(temp, strlen(shapename) + 1, shapename);
	return temp;
}

//Sphere
Sphere::Sphere(float pi):Pi(pi) {rad = 0; }
void Sphere::setrad(float rad){this->rad = rad; }
void Sphere::area()
{
	cal = 4 * Pi * rad;
	cal*= cal;
}
float Sphere::getarea() { return cal; }

//Rec
Rec::Rec()
{
	length = 0;
	height = 0;
	cal = 0;
}
void Rec::setheight(float height) { this->height = height; } //setting height
void Rec::setlength(float length) { this->length = length; } //setting length
float Rec::getlength() { return length; } //getting length
float Rec::getheight() { return height; } //getting height
float Rec::getarea() { return cal; } // returning the calculated area
void Rec::area(){ cal = length * height; } // calculating total area

//Cylen
Cylen::Cylen(float pi):Pi(pi)
{
	rad = 0;
	height = 0;
}
void Cylen::setheight(float height) { this->height = height; } //setting height
void Cylen::setrad(float rad) { this->rad = rad; } //setting length
float Cylen::getheight() { return height; } //getting length
float Cylen::getrad() { return rad; } //getting height
float Cylen::getarea() { return cal; } // returning the calculated area
void Cylen::area() { cal = Pi* rad * 2 *height; } // calculating total area

//Paint
void Paint::setarea(float area) { this->area = area; } // setting area of the shape;
void Paint::setcov(float covofpaint) { this->cov_of_p = covofpaint; } //setting coverage of paint
void Paint::calculate() { amount = area / cov_of_p; } // caluclating the amount of  paint needed to paint the shape
float Paint::getamount() { return amount; }