#include<iostream>
using namespace std;
#pragma once

class Shape
{
//	float cal;
	char* shapename;
public:
	Shape();
	//float getarea();
	virtual void area() = 0; // now as function is virtual and is = 0, so this class is Abstract now.
	void setname(char* name);
	char* tostring();// will return the name of shape;
};