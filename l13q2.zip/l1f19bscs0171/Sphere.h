#include "Shape.h"

class Sphere :public Shape
{
	char* shapeName;
	const int Pi = 3.14;
	float rad, cal;
public:
	Sphere(float pi);
	void setrad(float rad);
	float getrad();
	float getarea();
	void area();
};