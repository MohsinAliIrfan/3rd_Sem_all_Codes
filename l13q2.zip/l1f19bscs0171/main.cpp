#include "Shape.h"
#include "Sphere.h"
#include "Rec.h"
#include "Cylen.h"
#include "Paint.h"

int main() {

	char* name = new char[20];
	Sphere sph(3.14);
	sph.setrad(15);
	sph.area();
	cout << "\n Area of Sphere is: " << sph.getarea();

	Rec rec;
	rec.setlength(20);
	rec.setheight(35);
	rec.area();
	cout << "\n\n Rectangle:";
	cout << "\n Lenght = " << rec.getlength();
	cout << "\n Height = " << rec.getheight();
	cout << "\n Area of Rectangle is: " << rec.getarea();

	Cylen cy(3.14);
	cy.setheight(30);
	cy.setrad(10);
	cy.area();
	cout << "\n\n Cylender: ";
	cout << "\n Height = " << cy.getheight();
	cout << "\n Radius = " << cy.getrad();
	cout << "\n AREA = " << cy.getarea();

	Paint p;
	int cover = 2;
	p.setarea(sph.getarea());
	p.setcov(cover);
	p.calculate();
	cout << "\n\n Amount of paint needed to paint a Sphere is: " << p.getamount();
	
	p.setarea(rec.getarea());
	p.setcov(cover);
	p.calculate();
	cout << "\n\n Amount of paint needed to paint a Rectangle is: " << p.getamount();

	p.setarea(cy.getarea());
	p.setcov(cover);
	p.calculate();
	cout << "\n\n Amount of paint needed to paint a Cylender is: " << p.getamount();
	
	return 0;
}