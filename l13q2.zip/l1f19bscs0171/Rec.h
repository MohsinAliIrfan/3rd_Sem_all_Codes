#include "Shape.h"

class Rec : public Shape
{
	float length, height;
	float cal;
public:
	Rec();
	void setlength(float length);
	void setheight(float height);
	float getlength();
	float getheight();
	float getarea();
	void area();
};