#include"marks.h"
#include"Chem.h"
#include"math.h"
#include"physics.h"

int main()
{
	int num , i=0;
	char* name = new char[100];
	int phy = 0, chem = 0, math = 0;
	bool check = true;
	
	Marks *obj = new Marks[num] ;
	Physics *obj1 = new Physics[num];
	Chemistry *obj2 = new Chemistry[num];
	Math *obj3 = new Math[num];
	
	cout << "\n Enter Total Number of Students: "; cin >> num;
	while (i < num)
	{
		cout << "\n Enter Name "; cin.getline(name, 100);
		obj[i].setname(name);
		do
		{
			cout << "\n Enter Physics Marks: "; cin >> phy;
			check = obj1[i].setmarks(phy);

		} while (check);
		do
		{
			cout << "\n Enter Chemistry Marks: "; cin >> chem;
			check = obj1[i].setmarks(chem);

		} while (check);
		do
		{
			cout << "\n Enter Math Marks: "; cin >> math;
			check = obj1[i].setmarks(math);

		} while (check);
		i++;
	}
	i = 0;
	int sum = 0;
	while (i < 3)
	{
		sum += obj1[i].getmarks() + obj2[i].getmarks() + obj3[i].getmarks();
		i++;
	}
	cout << "\n The Sum of Total Class is " << sum;
	cout << "\n\n\n Average  =  " << sum / num;
	
}