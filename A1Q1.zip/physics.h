#include "marks.h"

class Physics : public Marks
{
	int marks;
public:
	bool setmarks(int marks);
	int getmarks();
	//void 
};