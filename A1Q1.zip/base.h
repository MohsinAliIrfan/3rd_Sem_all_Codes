#include<iostream>
using namespace std;
#pragma once

class BaseClass
{
	int width;
	int height;
public:
	void setwidth(int width);
	void setheight(int height);
	int getwidth();
	int getheight();
	void display();
};