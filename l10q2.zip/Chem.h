#include "marks.h"

class Chemistry : public Marks
{
	int marks;
public:
	bool setmarks(int marks);
    int getmarks();
};