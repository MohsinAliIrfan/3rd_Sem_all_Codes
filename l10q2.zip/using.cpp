#include"marks.h"
#include"physics.h"
#include"Chem.h"
#include"math.h"

char* Marks::deepcopy(char* arr) 
{
	if (name)
		delete[]name;

	this->name = new char[strlen(arr) + 1];
	strcpy_s(name, strlen(arr) + 1, arr);
	return name;
}
void Marks::setname(char *arr) {
	name = deepcopy(arr);
}
void Marks::setrollno() {
	this->rollno = rand();
}
char* Marks::getname()
{
	char* arr = new char[strlen(name) + 1];
	strcpy_s(arr, strlen(name) + 1, name);
	return arr;
}
int Marks::getrollno() {
	return rollno;
}
void Marks::setsum(int sum) {
	this->sum = sum;
}

Marks::~Marks() {
	if (name)
		delete[]name;
}

bool Physics::setmarks(int marks) 
{
	if (marks >= 0) {
		this->marks = marks;
		return true;
	}
	return false;
}
int Physics::getmarks() {
	return marks;
}
bool Chemistry::setmarks(int marks)
{
	if (marks >= 0) {
		this->marks = marks;
		return true;
	}
	return false;
}

bool Math::setmarks(int marks) 
{
	if (marks >= 0) {
		this->marks = marks;
		return true;
	}
	return false;
}
}