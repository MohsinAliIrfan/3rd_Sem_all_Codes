#include "marks.h"

class Math : public Marks
{
	int marks;
public:
	bool setmarks(int marks);
	int getmarks();
};