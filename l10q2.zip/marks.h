#include<iostream>
#include<random>
using namespace std;

class Marks
{
	int rollno , sum;
	//int phy, chem, math;
	char* name;
public:
	void setrollno();
	void setname(char *arr);
	int getrollno();
	char* getname();
	char* deepcopy(char* arr);
	void setsum(int sum);
	~Marks();
	//void setphy(int phy);
	//void setchem(int chem);
	//oid setmath(int math);
	//void setname(int size, char* name);
};