#include"Player.h"
//#include<iostream>

int Player::count = 0;

int main()
{
	char* name = new char[50];
	int age = 0;
	static int count;
	cout << "\n Enter Name: "; cin.getline(name,100);
	cout << "\n Enter Age: "; cin >> age;

	Player p1(name, age);
	p1.setage(age);
	p1.setname(name);
	p1.getage();
	p1.getname();
	p1.getcount();
	
	cout << "\n\n The Name you Enterd is: " << p1.getname();
	cout << "\n Your Age: " << p1.getage();
	cout << "\n COUNT = " << Player::getcount();

	cout << "\n\n Enter Name: "; cin.getline(name, 100); cin.getline(name, 100);
	cout << "\n Enter Age: "; cin >> age;

	Player p2(name, age);
	p2.setage(age);
	p2.setname(name);
	p2.getage();
	p2.getname();
	p2.getcount();

	cout << "\n\n The Name you Enterd is: " << p2.getname();
	cout << "\n Your Age: " << p2.getage();
	cout << "\n COUNT = " << Player::getcount();

	cout << "\n\n Enter Name: "; cin.getline(name, 100); cin.getline(name, 100);
	cout << "\n Enter Age: "; cin >> age;

	Player p3(name, age);
	p3.setage(age);
	p3.setname(name);
	p3.getage();
	p3.getname();
	p3.getcount();

	cout << "\n\n The Name you Enterd is: " << p3.getname();
	cout << "\n Your Age: " << p3.getage();
	cout << "\n COUNT = " << Player::getcount();
	
	cout << "\n\n Enter Name: "; cin.getline(name, 100); cin.getline(name, 100);
	cout << "\n Enter Age: "; cin >> age;

	Player p4(name, age);
	p4.setage(age);
	p4.setname(name);
	p4.getage();
	p4.getname();
	p4.getcount();

	cout << "\n\n The Name you Enterd is: " << p4.getname();
	cout << "\n Your Age: " << p4.getage();
	cout << "\n COUNT = " << Player::getcount();

	delete[]name;

	return 0;
}