#include"Player.h"

Player::Player()
{
	name = new char[1];
	age = 0;
}
Player::Player(char* n, int age) 
{
	count += 1;
	name = new char(strlen(n)+1);
	this->age = age;
}
void Player::setname(char* n)
{
	if (name == nullptr)
		name = new char[strlen(n) + 1];
	else 
	{
		delete[]name;
		name = new char[strlen(n) + 1];
	}
	strcpy_s(name, strlen(n) + 1, n);
}
void Player::setage(int age) 
{
	this->age = age;
}
char* Player::getname() 
{
	char* newname = new char[strlen(name) + 1];
	strcpy_s(newname, strlen(name) + 1, name);
	return name;
}
int Player::getage() {
	return age;
}
int Player::getcount() {
	return count;
}
Player::~Player(){
	delete[]name;
}