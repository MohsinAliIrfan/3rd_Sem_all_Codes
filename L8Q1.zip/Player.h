#include<iostream>
using namespace std;
#pragma once

class Player
{
	char* name;
	int age = 0;
	static int count;
public:
	Player();
	Player(char* n= NULL, int age = 0);
	void setname(char *n);
	void setage(int age);
	char* getname();
	int getage();
    static int getcount();
	~Player();
};