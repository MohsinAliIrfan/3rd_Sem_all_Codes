#include<iostream>
using namespace std;
#pragma once

class Base
{
public:
    virtual void testFunction();
};

class Derived : public Base
{
public:
    void testFunction();
};