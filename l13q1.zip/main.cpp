#include "task1.h"
int main(void) {

    Base* ptr = new Base;
    ptr->testFunction();         // prints "Base class"
    delete ptr;
    ptr = new Derived;
    ptr->testFunction();         // prints "Base class" because the base class function is not virtual
    delete ptr;
    return 0;
}

//Before Making the function the  funciotn virtual, ptr was calling the same base funtion
// When we made that funtion virtual, ptr stopped calling the same base function for derived class.