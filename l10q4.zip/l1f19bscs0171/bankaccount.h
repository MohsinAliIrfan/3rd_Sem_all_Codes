#include<iostream>
using namespace std;
#pragma once

class BankAccount
{
protected:
	double num;
	int acc_no;
	double blnc;
public:
	BankAccount(int accno = 0);
	bool setaccno(int acc_no);
	int getaccno();
	void setmoeny(int mon);
	double getmoeny();
	bool withdraw(int amount);
	void deposit(int amount);
	void diplay();
};