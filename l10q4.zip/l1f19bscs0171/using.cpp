#include"bankaccount.h"
#include"checking.h"
#include"savings.h"

BankAccount::BankAccount(int accno) {
	this->acc_no = accno;
	blnc = 5000;
}
bool BankAccount::setaccno(int accno)
{
	if (accno > 0) {
		this->acc_no = accno;
		num = accno;
		return true;
	}
	return false;
}
void BankAccount::setmoeny(int mon) {
	this->blnc = mon;
}
int BankAccount::getaccno() {
	return acc_no;
}
double BankAccount::getmoeny() {
	return blnc;
}
bool BankAccount::withdraw(int amount)
{
	if (amount < blnc)
	{
		this->blnc -= amount;
		cout << "\n Amount Withdrawl ";
		return true;
	}
	return false;

}
void BankAccount::deposit(int amount) {
	this->blnc += amount;
	cout << "\n Amount Deposited";
}
void BankAccount::diplay() {
	cout << "\n Detailes:";
	cout << "\n Account Number: " << acc_no;
	cout << "\n Balance: " << blnc << "rs";
}

CheckingAccount::CheckingAccount() {
	this->intrest = 0,this->min = 0, this->service = 0;
}


bool CheckingAccount::setintrest(int intrest)
{
	if (intrest > 0) {
		this->intrest = intrest;
		return true;
	}
	return false;
}
bool CheckingAccount::setmin(int min)
{
	if (min > 0) {
		this->min = min;
		return true;
	}
	return false;
}
bool CheckingAccount::setservice(int service)
{
	if (service > 0) {
		this->service = service;
		return true;
	}
	return false;
}
int CheckingAccount::getintrest() {
	return intrest;
}
int CheckingAccount::getmin() {
	return min;
}
int CheckingAccount::getservice() {
	return service;
}
bool CheckingAccount::check()
{
	if (blnc < min)
		return false;
	return true;
}
bool CheckingAccount::withdraw(int amount)
{
	if (amount >= blnc)
		return false;

	this->blnc -= amount;
	return true;
}
bool CheckingAccount::writecheck(int amount, int accno)
{
	if (amount > 0 && amount <= blnc && accno == acc_no) {
		this->blnc -= amount;
		return true;
	}
	return false;
}
void CheckingAccount::display()
{
	cout << endl;
	cout << "\n Account Number: " << acc_no;
	cout << "\n Remianing Balance: " << blnc;
	cout << "\n Intrest Rate: " << intrest;
	cout << "\n Service Charges: " << service;
}

SavingAccount::SavingAccount() {
	this->intrest = 0, this->min = 0, this->service = 0;
}

bool SavingAccount::setintrest(int amount)
{
	if (amount > 0) {
		this->service = service;
		return true;
	}
	return false;
}
int SavingAccount::getintrest() {
	return intrest;
}
bool SavingAccount::withdraw(int amount)
{
	if (amount <= blnc) {
		if (amount <= blnc)
			this->blnc -= amount;
		return true;
	}
	return false;
}
float SavingAccount::postintrest(int blnc) {
	int ans = (blnc / 100) * intrest;
	return ans;
}

void SavingAccount::display()
{
	cout << "\n Account Number: " << BankAccount::getaccno();
	cout << "\n Balance: " << blnc;
	cout << "\n Intrest Rate: " << intrest;
}