#include"bankaccount.h"
#pragma once
class SavingAccount : public BankAccount
{
	float intrest;
	int min, service;
public:
	SavingAccount();
	bool setintrest(int amount);
	int getintrest();
	float postintrest(int blnc);
	bool withdraw(int amount);
	void display();
};