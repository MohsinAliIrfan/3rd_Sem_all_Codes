#include"bankaccount.h"
#pragma once

class CheckingAccount : public BankAccount
{
	float intrest;
	int min, service;
public:
	CheckingAccount();
	bool setintrest(int intrest);
	int getintrest();
	bool setmin(int min);
	int getmin();
	bool setservice(int service);
	int getservice();
	bool check();
	bool withdraw(int amount);
	bool writecheck(int amount, int acc);
	void display();
};