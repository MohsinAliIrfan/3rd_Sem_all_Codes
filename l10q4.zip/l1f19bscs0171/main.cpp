#include "bankaccount.h"
#include "checking.h"
#include "savings.h"

int main()
{
	bool check = true;
	int acc = 0, opt = 0, amount = 0;
	BankAccount obj(acc);
	CheckingAccount obj1;
	SavingAccount obj2;
	cout << "\n 1. Set Account Number: ";
	cout << "\n 2. Get Account Number: ";
	cout << "\n 3. Display Money: ";
	cout << "\n 4. WithDraw Money: ";
	cout << "\n 5. Deposit Money: ";
	cout << "\n 6. Display Bank Account Class: ";
	cout << "\n 7. Set Intrest Rate: ";
	cout << "\n 8. Get Intrest Rate: ";
	cout << "\n 9. Set Minimum Balance: ";
	cout << "\n10. Get Minimum Balance: ";
	cout << "\n11. Set Service Charges: ";
	cout << "\n12. Get Sevice Charges: ";
	cout << "\n13. WithDraw Money: ";
	cout << "\n14. Cash Check:";
	cout << "\n15 Display Money: ";
	cout << "\n16 Enter Intrest Rate(3rd Class) ";
	cout << "\n17 Get Intrest:";
	cout << "\n18 Get Post Intrest: ";
	cout << "\n19 WithDraw Moeny: ";
	cout << "\n20 Display Output:";
	cout << "\n\n21 For Exit, press 21:";

	do
	{
		cout << "\n\n Enter Account Number: "; cin >> acc;
		//cout << "hello";
		check = obj.setaccno(acc);
		obj1.setaccno(acc);
	} while (!check);
	cout << "\n Account Number Updated: ";

	while (true)
	{
		cout << "\n\n Enter Option: "; cin >> opt;
		if (opt == 1)
		{
			do{
				cout << "\n\n Enter Account Number: "; cin >> acc;
				//cout << "hello";
				check = obj.setaccno(acc);
				obj1.setaccno(acc);
			} while (!check);
			cout << "\n Account Number Updated: ";
		}
		else if (opt == 2) cout << "\n Account Number: " << obj.getaccno();
		else if (opt == 3) cout << "\n Money in Account = " << obj.getmoeny();
		else if (opt == 4)
		{
			do
			{
				cout << "\n Enter Amount to WithDrawl: "; cin >> amount;
				check = obj.withdraw(amount);

				if (!check)
					cout << "\n Enter Correct Amount!";
			} while (!check);
			cout << "\n Money WithDrawl";
		}
		else if (opt == 5) {
			cout << "\n Enter Amount to Deposit: "; cin >> amount;
			obj.deposit(amount);
			cout << "\n Money Deposited: ";
		}
		else if (opt == 6) obj.diplay();

		else if (opt == 7)
		{
			do
			{
				cout << "\n Enter Intrest Rate: "; cin >> amount;
				check = obj1.setintrest(amount);
				if (!check)
					cout << "\n Enter Correct Amount: ";
			} while (!check);
			cout << "\n Intrest Rate Updated:";
		}
		else if (opt == 8) cout << "\n Intrest Rate = " << obj1.getintrest();
		else if (opt == 9)
		{
			do
			{
				cout << "\n Enter Minimum Amount: "; cin >> amount;
				check = obj1.setmin(amount);
				if (!check)
					cout << "\n Enter Correct Amount: ";
			} while (!check);
			cout << "\n Minimum Amount Updated";
		}
		else if (opt == 10) cout << "\n Minimum Amount is: " << obj1.getmin();
		else if (opt == 11)
		{
			do
			{
				cout << "\n Enter Service Charges: "; cin >> amount;
				check = obj1.setservice(amount);
				if (!check)
					cout << "\n Enter Correct Amount: ";
			} while (!check);
			cout << "\n Service Charges Updated: ";
		}
		else if (opt == 12) cout << "\n Service Charges = " << obj1.getservice();
		else if (opt == 13)
		{
			do
			{
				cout << "\n Enter Amount to WithDrawl: "; cin >> amount;
				check = obj1.withdraw(amount);
				if (!check)
					cout << "\n Enter Correct Amount!";
			} while (!check);
			cout << "\n Amont WithDrawl ";
		}
		else if (opt == 14)
		{
			do
			{
				cout << "\n Enter Account Number: "; cin >> acc;
				cout << "\n Enter Amount "; cin >> amount;
				check = obj1.writecheck(amount, acc);
				if (!check)
					cout << "\n Enter Correct Values ";
			} while (!check);
			cout << "\n Check Cashed: ";
			obj.setmoeny(obj1.getmoeny());
		}
		else if (opt == 15)
			obj1.display();
		else if (opt == 16)
		{
			do
			{
				cout << "\n Enter Intrest Rate: "; cin >> amount;
				check = obj2.setintrest(amount);
				if (!check)
					cout << "\n Enter Correct Amount: ";
			} while (!check);
			cout << "\n Intrest Rate Updated:";
		}
		else if (opt == 17) cout << "\n Intrest = " << obj2.getintrest();
		else if (opt == 18) cout << "\n Amount of Float Intrest: " << obj2.postintrest(obj1.getmoeny());
		else if (opt == 19)
		{
			do
			{
				cout << "\n Enter Amount to WithDrawl: "; cin >> amount;
				check = obj.withdraw(amount);

				if (!check)
					cout << "\n Enter Correct Amount!";
			} while (!check);
			cout << "\n Money WithDrawl";
		}
		else if (opt == 20) obj2.display();

		else if (opt == 21) break;
		//else cout << "\n Enter Correct Option ";
	}
	return 0;
}